export class User
{
	id: number;
    email: string;
    firstname: string;
    lastname: string;
    address: number;
    password: string;
    phone: number;
}