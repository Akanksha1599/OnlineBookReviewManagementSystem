import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-afooter',
  templateUrl: './afooter.component.html',
  styleUrls: ['./afooter.component.css']
})
export class AfooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
